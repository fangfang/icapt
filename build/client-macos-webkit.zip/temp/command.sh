# phantomjs phantom.js http://www.taobao.com taobao.png
phantomjs /Users/chencheng/Documents/Work/WorkSpace/icapt/tools/PhantomJS/phantom.js $1 $2
